<?php
// Heading
$_['heading_title']    = 'Infinitescroll';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Infinitescroll module!';
$_['text_edit']        = 'Edit Infinitescroll Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Infinitescroll module!';